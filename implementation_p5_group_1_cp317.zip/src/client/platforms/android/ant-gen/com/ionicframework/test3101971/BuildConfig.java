/** Automatically generated file. DO NOT MODIFY */
package com.ionicframework.test3101971;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}